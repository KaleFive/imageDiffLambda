const AWS = require("aws-sdk")
const s3 = new AWS.S3()
const fs = require("fs")

console.log("hello")
// pullNewBranchS3Image("kalefive.unique.bucket.name", "cnnImage.png")
//   .then(function(buffer) {
//     debugger
//   })
let branchName = ""
let params = {
  Bucket: "kalefive.unique.bucket.name",
  Prefix: "branches/" + branchName
}
let diffPath = "./cnnImage.png"
fs.readFile(diffPath, function (err,data) {
  if (err) {
    return console.log(err);
  }
  let imageStream = fs.createReadStream(diffPath)
  let params = {
    Bucket: 'kalefive.unique.bucket.name',
    Key: "diff/testfolders/cnnImage.png",
    Body: imageStream,
    ACL: 'public-read'
  };
  console.log("uploading to S3")
  s3.putObject(params, function(data) {
    console.log(data)
    console.log("right before resolve")
    resolve()
  });
});
// s3.listObjectsV2(params, function(err, data) {
//   if (data.KeyCount == 0) {
//   }
//
//   if (data.KeyCount > 0) {
//     data.Contents.forEach(function(obj) {
//       console.log(obj.Key)
//     })
//   }
// })
