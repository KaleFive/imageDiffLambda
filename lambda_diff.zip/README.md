# imageDiffLambda
Lambda function to run screenshot diff/comparison tool<br/>
run `zip -r ../../lambda_diff.zip *` from root of this repo to create zip file for upload to AWS
